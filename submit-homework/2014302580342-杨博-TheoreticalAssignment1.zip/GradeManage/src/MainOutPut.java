import java.io.File;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import java.io.FileOutputStream;

/*
��2014302580342 ���д
ʹ����poi��� ���������� ��������ֻ�ϴ�Դ������
*/
public class MainOutPut {
	public static ClassInfo data[];
	public void processScoreTable(File input) throws IOException{
		//�����ļ�
		if(!input.exists()){
			System.out.println("�ļ�������");
			return;
		}
		ReadExcel rf = new ReadExcel();
		data = new ClassInfo[23];
		data = rf.readExcel(input);
		//System.out.print(data[1].credit);
		
		//���ݲ���
		GradeCalc calc = new GradeCalc();
		calc.SortGrade(data);
		calc.GetAverage(data);
		calc.GetGPAAverage(data);
		
		//����ļ�
		@SuppressWarnings("resource")
		HSSFWorkbook output = new HSSFWorkbook();
		HSSFSheet sheet = output.createSheet("�ɼ���");  
		HSSFRow row ;
		HSSFCell cell;
		for (int rIndex = 0; rIndex < 24;rIndex++){
			row = sheet.createRow((int) rIndex);
			for(int cIndex = 0; cIndex<11;cIndex++){
				cell = row.createCell(cIndex);
				cell.setCellValue(data[rIndex].credit);
				switch(cIndex){
				case 0:
					cell.setCellValue(data[rIndex].number);
					//System.out.print(NewClass[rIndex].number +"\t");
					break;
				case 1:
					cell.setCellValue(data[rIndex].name);
					//System.out.print(NewClass[rIndex].name +"\t");
					break;
				case 2:
					cell.setCellValue(data[rIndex].type);
					break;
				case 3:
					cell.setCellValue(data[rIndex].credit);
					break;
				case 4:
					cell.setCellValue(data[rIndex].teacher);
					break;
				case 5:
					cell.setCellValue(data[rIndex].place);
					break;
				case 6:
					cell.setCellValue(data[rIndex].stype);
					break;
				case 7:
					cell.setCellValue(data[rIndex].year);
					break;
				case 8:
					cell.setCellValue(data[rIndex].term);
					break;
				case 9:
					cell.setCellValue(data[rIndex].grade);
					break;
				case 10:
					cell.setCellValue(data[rIndex].operation);
					break;	
				}
			}
		}
		try  
	        {  
	            FileOutputStream fileout = new FileOutputStream("E:/grade_after.xls");  
	            output.write(fileout);  
	            fileout.close();  
	        }  
	        catch (Exception e)  
	        {  
	            e.printStackTrace();  
	        }  
	
	}

	 public static void main(String[] args) throws IOException{
		 File file = new File("E:/grade.xlsx");
		 MainOutPut mop = new MainOutPut();
		 mop.processScoreTable(file);	
	 }
	

}
