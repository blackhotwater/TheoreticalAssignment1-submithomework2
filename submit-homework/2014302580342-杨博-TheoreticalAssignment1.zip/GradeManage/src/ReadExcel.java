import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//��ȡԭexcel�ļ�
public class ReadExcel {

	@SuppressWarnings("resource")
	public ClassInfo[] readExcel(File file) throws IOException{
		
			ClassInfo[] NewClass;
			NewClass= new ClassInfo[24];
			InputStream inputStream = new FileInputStream(file);
			Workbook wb = null;
			wb = new XSSFWorkbook(inputStream);
			Sheet sheet = wb.getSheetAt(0);
			for(int rIndex = 0; rIndex < 24; rIndex ++){
				NewClass[rIndex] = new ClassInfo();
				Row row = sheet.getRow(rIndex);
				//System.out.print(rIndex);
				if(row != null){
					int firstCellIndex = row.getFirstCellNum();
					int lastCellIndex = row.getLastCellNum();
					for(int cIndex = firstCellIndex; cIndex < lastCellIndex; cIndex ++){
						Cell cell = row.getCell(cIndex);
						
						String value = "";
						if(cell != null){
							value = cell.toString();
							//�������е�ֵ�����½������ݽṹ��
							if(rIndex >= 0){
								switch(cIndex){
									case 0:
										NewClass[rIndex].number = value;
										//System.out.print(NewClass[rIndex].number +"\t");
										break;
									case 1:
										NewClass[rIndex].name = value;
										//System.out.print(NewClass[rIndex].name +"\t");
										break;
									case 2:
										NewClass[rIndex].type = value;
										break;
									case 3:
										NewClass[rIndex].credit = value;
										break;
									case 4:
										NewClass[rIndex].teacher = value;
										break;
									case 5:
										NewClass[rIndex].place = value;
										break;
									case 6:
										NewClass[rIndex].stype = value;
										break;
									case 7:
										NewClass[rIndex].year = value;
										break;
									case 8:
										NewClass[rIndex].term = value;
										break;
									case 9:
										NewClass[rIndex].grade = value;
										break;
									case 10:
										NewClass[rIndex].operation = value;
										break;	
								}
							}
							
						}
					}
					//System.out.println();
					
				}
			}

		return NewClass;
	}
}
