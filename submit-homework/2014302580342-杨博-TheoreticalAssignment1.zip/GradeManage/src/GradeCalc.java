//进行各种数据处理的算法
class GradeCalc {

	public ClassInfo[] SortGrade(ClassInfo[] a){
		ClassInfo temp;
		int length = a.length;
		for(int i = 1; i < length - 1; i++){
			for(int j =1; j< length -i -1;j++){
				double grade1 = Double.parseDouble(a[j].grade);
				double grade2 = Double.parseDouble(a[j+1].grade);
				if(grade1 >0 && grade2 >0){
					if(grade1<grade2){
						temp = a[j];
						a[j] = a[j+1];
						a[j+1] = temp;
					}
				}
			}
		}	
		System.out.println("排序成功");
		return a;
	}

    public  double GetAverage(ClassInfo[] data) {
        double Average = 0;
        double CreditAll = 0;
        for (int i = 1; i < data.length ; i++) {
        	double Grade = Double.parseDouble(data[i].grade);
            if(Grade  > 0){
            Average += Grade * Double.parseDouble(data[i].credit) ;
            CreditAll += Double.parseDouble(data[i].credit);
            }
        }
        System.out.println("平均分计算成功，平均分为  " + Average / CreditAll);
        return Average / CreditAll;
    }


    public double GetGPAAverage(ClassInfo[] a) {
        double GpaAll = 0;
        double CreditAll = 0;
        double GPA = 0;
        for (int i = 1; i < a.length; i++) {
        	double Grade = Double.parseDouble(a[i].grade);
        	if(Grade > 0){
        		if (Grade < 60) GPA = 0;
        		else if (Grade >= 60 && Grade <= 63) GPA = 1.0;
            	else if (Grade >= 64 && Grade <= 67) GPA = 1.5;
            	else if (Grade >= 68 && Grade <= 71) GPA = 2.0;
            	else if (Grade >= 72 && Grade <= 74) GPA = 2.3;
            	else if (Grade >= 75 && Grade <= 77) GPA = 2.7;
            	else if (Grade >= 78 && Grade <= 81) GPA = 3.0;
            	else if (Grade >= 82 && Grade <= 84) GPA = 3.3;
            	else if (Grade >= 85 && Grade <= 89) GPA = 3.7;
            	else if (Grade >= 90 && Grade <= 100) GPA = 4.0;
            	else System.out.println("error");
        		GpaAll += Double.parseDouble(a[i].credit) * GPA;
        		CreditAll += Double.parseDouble(a[i].credit);
        	}
        }
        System.out.println("绩点计算成功，绩点为  " + GpaAll / CreditAll);
        return GpaAll / CreditAll;
    }

}

